console.log("async get data...")

$(document).ready(function() {
    $.ajax({
    	url: "/SampleWeb/rest/lastn/50", 	//omitted http://localhost:9080
    	success: 
    		function(result){
    			console.log(result);
    			for (var i = 0; i < result.length; i++) {
    			    var myJSON = JSON.stringify(result[i]);
    			    var obj = JSON.parse(myJSON);
    			    $("#myTable").append("<tr><td>" + obj.value + "</td><td>" + obj.id + "</td>" + obj.date + "</tr>");	//why not \n???
    			}
    			console.log("appended...");
    		}
    });
});