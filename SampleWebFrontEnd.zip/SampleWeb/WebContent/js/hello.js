console.log("async get data...")

$(document).ready(function() {
    $.ajax({
    	url: "/SampleWeb/rest/lastn/50", 	//omitted http://localhost:9080
    	success: 
    		function(result){
    			console.log(result);
    			for (var i = 0; i < result.length; i++) {
    			    var myJSON = JSON.stringify(result[i]);
    			    var obj = JSON.parse(myJSON);
    			    $("#listData").append(obj.value + " - " + obj.id + " - " + obj.date + "<br>");	//why not \n???
    			}
    			console.log("appended...");
    		}
    });
});