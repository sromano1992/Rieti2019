package it.sistinf.wave3.servlet;

import java.io.IOException;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import it.sistinf.wave3.jpa.entity.SampleTable;

/**
 * Servlet implementation class PigioServlet
 */
@WebServlet("/pigio")
public class PigioServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@PersistenceContext(unitName = "SampleWeb")
	private EntityManager em;

    /**
     * Default constructor. 
     */
    public PigioServlet() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		TypedQuery<SampleTable> query = em.createQuery("select s from SampleTable s where s.id = :id",
				SampleTable.class);
		query.setParameter("id", 1);
		List<SampleTable> results = query.getResultList();

		System.out.println(results);
		response.getWriter().append("Served at: ").append(request.getContextPath()).append(" ").append(new Date().toString());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
