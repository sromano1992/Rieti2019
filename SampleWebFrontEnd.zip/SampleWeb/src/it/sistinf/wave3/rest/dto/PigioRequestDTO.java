package it.sistinf.wave3.rest.dto;

public class PigioRequestDTO
{

	private long id;

	private String value;

	public PigioRequestDTO()
	{
	}

	public long getId()
	{
		return this.id;
	}

	public void setId(long id)
	{
		this.id = id;
	}

	public String getValue()
	{
		return this.value;
	}

	public void setValue(String value)
	{
		this.value = value;
	}

}