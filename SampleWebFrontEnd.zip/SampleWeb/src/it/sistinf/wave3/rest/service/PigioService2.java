package it.sistinf.wave3.rest.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Logger;

import javax.naming.InitialContext;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.UserTransaction;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import it.sistinf.wave3.jpa.entity.SampleTable;
import it.sistinf.wave3.rest.dto.PigioRequestDTO;
import it.sistinf.wave3.rest.dto.PigioResponseDTO;

@Path("/lastn")
public class PigioService2 {
	@PersistenceContext(unitName = "SampleWeb")
	private EntityManager em;

	private static final Logger LOGGER = Logger.getLogger(PigioService2.class.getName());

	@GET
	@Consumes("application/json")
	@Produces("application/json")
	@Path("/{num}")
	public Response lastN(@PathParam("num") int max) {
		try {
			TypedQuery<SampleTable> query = em.createQuery("select s from SampleTable s", SampleTable.class).setMaxResults(max);
			List<SampleTable> results = query.getResultList();

			if (results.size() == 0)
				return Response.status(Status.NOT_FOUND).build();

			ArrayList<PigioResponseDTO> toReturn = new ArrayList<PigioResponseDTO>();
			for (int i = 0; i < results.size(); i++) {
				SampleTable result = results.get(i);
				PigioResponseDTO dto = new PigioResponseDTO();
				dto.setId(result.getId());
				dto.setValue(result.getValue());
				dto.setDate(new Date());
				toReturn.add(dto);
			}

			return Response.ok(toReturn, MediaType.APPLICATION_JSON).build();
		} catch (Exception e) {
			e.printStackTrace();
			return Response.status(Status.INTERNAL_SERVER_ERROR).build();
		}
	}

}
