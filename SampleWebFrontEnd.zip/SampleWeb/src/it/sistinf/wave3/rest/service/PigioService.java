package it.sistinf.wave3.rest.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Logger;

import javax.naming.InitialContext;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.UserTransaction;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import it.sistinf.wave3.jpa.entity.SampleTable;
import it.sistinf.wave3.rest.dto.PigioRequestDTO;
import it.sistinf.wave3.rest.dto.PigioResponseDTO;

@Path("/pigio")
public class PigioService {
	@PersistenceContext(unitName = "SampleWeb")
	private EntityManager em;

	private static final Logger LOGGER = Logger.getLogger(PigioService.class.getName());

	@GET
	@Consumes("application/json")
	@Produces("application/json")
	@Path("/{id}")
	public Response get(@PathParam("id") Long id) {
		try {
			TypedQuery<SampleTable> query = em.createQuery("select s from SampleTable s where s.id = :id",
					SampleTable.class);
			query.setParameter("id", id);
			List<SampleTable> results = query.getResultList();

			if (results.size() == 0)
				return Response.status(Status.NOT_FOUND).build();

			SampleTable result = results.get(0);
			PigioResponseDTO dto = new PigioResponseDTO();
			dto.setId(result.getId());
			dto.setValue(result.getValue());
			dto.setDate(new Date());

			return Response.ok(dto).build();
		} catch (Exception e) {
			e.printStackTrace();
			return Response.status(Status.INTERNAL_SERVER_ERROR).build();
		}
	}

	@PUT
	@Consumes("application/json")
	@Produces("application/json")
	public Response put(PigioRequestDTO request) {
		UserTransaction tx = null;
		try {
			tx = (UserTransaction) new InitialContext().lookup("java:comp/UserTransaction");

			tx.begin();

			SampleTable st = new SampleTable();
			st.setId(request.getId());
			st.setValue(request.getValue());
			em.persist(st);

			tx.commit();

			return Response.ok().build();
		} catch (Exception e) {
			e.printStackTrace();
			try {
				if (tx != null && tx.getStatus() == javax.transaction.Status.STATUS_ACTIVE)
					tx.rollback();
			} catch (Exception ex) {
			}

			return Response.status(Status.INTERNAL_SERVER_ERROR).build();
		}

	}
}
