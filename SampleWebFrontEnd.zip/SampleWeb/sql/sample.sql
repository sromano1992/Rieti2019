drop table rieti2019.sample_table;

create table rieti2019.sample_table
(

	ID bigint not null primary key,
	"VALUE" varchar(50) not null
);

select * from rieti2019.sample_table;