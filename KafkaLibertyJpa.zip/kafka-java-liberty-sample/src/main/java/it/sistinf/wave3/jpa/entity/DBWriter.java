package it.sistinf.wave3.jpa.entity;

import javax.enterprise.context.Dependent;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

@Named
@Dependent
public class DBWriter {
    
    @PersistenceContext(unitName = "kafka-java-liberty-sample")
	private EntityManager em;
    
    public void store(SampleTable toStore) {
    	em.persist(toStore);    	
    }

}
